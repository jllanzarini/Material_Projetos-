import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="CadastroServlet", urlPatterns="/cadastro" ) 
public class CadastroServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException{
		
		String nome = req.getParameter("nome");
		String autor = req.getParameter("autor");
		String isbn = req.getParameter("isbn");
		String valor = req.getParameter("valor");
		String dtcom = req.getParameter("dtcom");
		String paginas = req.getParameter("paginas");
		String capa = req.getParameter("capa");
		String tema = req.getParameter("tema");
		
		PrintWriter writer = resp.getWriter();
		resp.setContentType("text/html");
		writer.println("<fieldset><legend>Dados do Livro: </legend>");
		writer.println("Nome do Livro: "+nome);
		writer.println("<br>Autor do Livro: "+autor);
		writer.println("<br>ISBN: "+ isbn);
		writer.println("<br>Valor Pago: "+valor);
		writer.println("<br>Data de Compra: "+dtcom);
		writer.println("<br>Numero de Páginas : "+ paginas);
		writer.println("<br>Tipo de Capa: "+capa);
		writer.println("<br>Temática: "+tema);
		writer.println("</fieldset>");
		
	}	
}
