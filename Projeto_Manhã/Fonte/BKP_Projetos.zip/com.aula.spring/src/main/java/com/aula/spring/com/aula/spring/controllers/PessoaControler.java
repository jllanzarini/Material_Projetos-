package com.aula.spring.com.aula.spring.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class PessoaControler {

}
