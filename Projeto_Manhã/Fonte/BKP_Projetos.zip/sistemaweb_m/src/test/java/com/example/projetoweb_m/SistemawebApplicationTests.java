package com.example.projetoweb_m;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemawebApplicationTests {

	@Test
	void contextLoads() {
	}

}
