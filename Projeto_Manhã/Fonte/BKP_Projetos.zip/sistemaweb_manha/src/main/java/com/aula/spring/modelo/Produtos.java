package com.aula.spring.modelo;

public class Produtos {

}
