package com.projetofinal.sistemaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemawebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemawebApplication.class, args);
	}

}
