package com.projetofinal.sistemaweb_t;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemawebTApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemawebTApplication.class, args);
	}

}
