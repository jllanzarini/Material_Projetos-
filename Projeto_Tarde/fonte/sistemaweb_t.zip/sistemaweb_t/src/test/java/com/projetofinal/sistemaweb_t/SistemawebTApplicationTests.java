package com.projetofinal.sistemaweb_t;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemawebTApplicationTests {

	@Test
	void contextLoads() {
	}

}
