package com.example.projetoweb_t;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetowebTApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetowebTApplication.class, args);
	}

}
