package com.example.demo.controle;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.repositorio.ProdutosRepositorio;

@Controller
public class ProdutosControle {
	
private ProdutosRepositorio produtosrepositorio;
	
	
	public ProdutosControle(ProdutosRepositorio produtosrepositorio ) {
		this.produtosrepositorio =produtosrepositorio;
	}
	//Listagem das Pessoas Cadastradas
		@GetMapping("/produtos")
		public String Produtos(Model model) {
			model.addAttribute("listaProdutos",produtosrepositorio.findAll());
			return "cadastros/lista_produtos";
		}
}
